#!/usr/bin/env sh
set -eu
replace=false
case "${1:-}" in
  '') ;;
  --replace) replace=true ;;
  *) printf '%s\n' 'Usage: sh install.sh [--replace]' >&2; exit 1 ;;
esac
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
source="$root/pets/shuangling"
target="${CODEX_HOME:-$HOME/.codex}/pets/shuangling"
hash_file() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
  else shasum -a 256 "$1" | awk '{print $1}'; fi
}
for name in pet.json spritesheet.webp; do
  expected=$(awk -v key="pets/shuangling/$name" '$2 == key {print $1}' "$root/CHECKSUMS.sha256")
  [ -n "$expected" ] && [ "$(hash_file "$source/$name")" = "$expected" ] || { printf 'Checksum failed: %s\n' "$name" >&2; exit 1; }
done
if [ -e "$target" ]; then
  if cmp -s "$source/pet.json" "$target/pet.json" && cmp -s "$source/spritesheet.webp" "$target/spritesheet.webp"; then
    printf 'Already installed: %s\n' "$target"; exit 0
  fi
  [ "$replace" = true ] || { printf '%s\n' 'A different version exists. Use --replace to back it up and replace it.' >&2; exit 1; }
  backup="$target.backup-$(date +%Y%m%d-%H%M%S)-$$"
  [ ! -e "$backup" ] || { printf '%s\n' 'Backup path already exists.' >&2; exit 1; }
  cp -R "$target" "$backup"
  printf 'Backup: %s\n' "$backup"
fi
mkdir -p "$target"
for name in pet.json spritesheet.webp; do
  cp "$source/$name" "$target/$name"
  cmp -s "$source/$name" "$target/$name" || { printf 'Installed file differs: %s\n' "$name" >&2; exit 1; }
done
printf 'Installed: %s\n' "$target"
printf '%s\n' 'Refresh the Codex pet list and select Shuangling. If absent, restart Codex.'
