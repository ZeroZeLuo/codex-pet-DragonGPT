# 上传到 GitHub，再换电脑安装

推荐：私有仓库保存展开的文件，Release 保存完整 ZIP。仓库便于查看说明和追踪版本，Release 便于以后直接下载一个安装包。

## 1. 创建或打开仓库

已有项目可以直接使用。新建时点击 GitHub 的 **New repository**，名称可用 `codex-pet-shuangling`，个人备份建议选择 **Private**。可以勾选初始化 README，使仓库先有一个提交；上传本包时用本包 README 替换它。

## 2. 上传展开的文件

在仓库首页点击 **Add file → Upload files**。解压本安装包后，把里面的 `README.md`、`UPLOAD-GITHUB.md`、两个安装脚本、`CHECKSUMS.sha256`、`pets/` 和 `source/` 等文件及目录拖进页面，保留目录结构。

上传的是包内内容，不要再套一层 `shuangling-github/` 文件夹。隐藏的 `.gitattributes` 和 `.gitignore` 也可以一并上传；前者供后续使用 Git 时保持文件字节一致。

提交说明可填写 `Add Shuangling pet v1.0.0`，然后按页面提示提交。个人新仓库可以直接提交；已有多人项目按该项目的分支规则操作。

网页上传支持每文件 25 MiB、每次最多 100 个文件。本包文件数和最大单文件均在此范围内。[GitHub 文件上传文档](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)

## 3. 保存可下载的版本包

打开 **Releases → Draft a new release**，创建标签 `v1.0.0`，标题填 `霜绫 v1.0.0`；描述可填“Codex v2 本地宠物，9 类动画、16 个方向，附安装脚本”。把本次生成的 `shuangling-v1.0.0.zip` 附加到附件区域，然后发布 Release。[GitHub Release 文档](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)

这样仓库中保存展开文件，ZIP 保存为 Release 附件。以后更新时可用 `v1.0.1` 等新标签保存新包。

## 4. 新电脑恢复

1. 安装 Codex 桌面应用，登录 GitHub。
2. 在 Releases 下载 `shuangling-v1.0.0.zip`，完整解压。
3. 在解压目录打开 PowerShell，运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

4. 刷新或重启 Codex，在宠物列表中选择“霜绫”。

也可以从仓库 **Code → Download ZIP** 下载展开的文件，解压后运行同一脚本。安装过程使用本地文件。
