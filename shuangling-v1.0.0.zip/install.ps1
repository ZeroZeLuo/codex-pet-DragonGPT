param([string]$CodexHome, [switch]$Replace)
$ErrorActionPreference = 'Stop'
if (-not $CodexHome) {
    if ($env:CODEX_HOME) { $CodexHome = $env:CODEX_HOME }
    else { $CodexHome = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex' }
}
$source = Join-Path $PSScriptRoot 'pets\shuangling'
$target = [IO.Path]::GetFullPath((Join-Path $CodexHome 'pets\shuangling'))
$checks = @{}
foreach ($line in Get-Content -LiteralPath (Join-Path $PSScriptRoot 'CHECKSUMS.sha256')) {
    if ($line -match '^([a-f0-9]{64})  (.+)$') { $checks[$Matches[2]] = $Matches[1] }
}
foreach ($name in @('pet.json','spritesheet.webp')) {
    $key = 'pets/shuangling/' + $name
    $actual = (Get-FileHash -LiteralPath (Join-Path $source $name) -Algorithm SHA256).Hash
    if (-not $checks.ContainsKey($key) -or $actual -ne $checks[$key]) { throw "Checksum failed: $key" }
}
$manifest = Get-Content -LiteralPath (Join-Path $source 'pet.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($manifest.id -ne 'shuangling' -or $manifest.spriteVersionNumber -ne 2 -or $manifest.spritesheetPath -ne 'spritesheet.webp') { throw 'Invalid pet manifest' }
if (Test-Path -LiteralPath $target) {
    $same = $true
    foreach ($name in @('pet.json','spritesheet.webp')) {
        $installed = Join-Path $target $name
        if (-not (Test-Path -LiteralPath $installed -PathType Leaf) -or (Get-FileHash -LiteralPath $installed -Algorithm SHA256).Hash -ne $checks['pets/shuangling/'+$name]) { $same = $false }
    }
    if ($same) { Write-Output "Already installed: $target"; exit 0 }
    if (-not $Replace) { throw 'A different pet version exists. Run again with -Replace to back it up and replace it.' }
    $backup = $target + '.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8)
    Copy-Item -LiteralPath $target -Destination $backup -Recurse
    Write-Output "Backup: $backup"
}
New-Item -ItemType Directory -Path $target -Force | Out-Null
foreach ($name in @('pet.json','spritesheet.webp')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $target $name) -Force
    if ((Get-FileHash -LiteralPath (Join-Path $target $name) -Algorithm SHA256).Hash -ne $checks['pets/shuangling/'+$name]) { throw "Installed checksum failed: $name" }
}
Write-Output "Installed: $target"
Write-Output 'Refresh the Codex pet list and select Shuangling. If absent, restart Codex.'
